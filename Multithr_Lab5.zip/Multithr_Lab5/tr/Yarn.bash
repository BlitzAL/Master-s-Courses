spark-submit --master yarn --deploy-mode client $1
