apt-get install dos2unix
dos2unix Master.bash