docker stack deploy --compose-file spark-cluster.yml spark

