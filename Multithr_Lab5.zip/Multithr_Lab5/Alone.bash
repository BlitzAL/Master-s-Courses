spark-submit --master spark://my-hadoop-master:7077 $1
